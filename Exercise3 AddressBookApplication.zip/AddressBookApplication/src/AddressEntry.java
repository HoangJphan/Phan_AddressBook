
public class AddressEntry {
	String firstName;
	String lastName;
	String Street;
	String City;
	String State;
	int Zip;
	String Telephone;
	String Email;
	
	AddressEntry(String firstName,String lastName,String Street,
		String City,String State,int Zip,String Telephone,
		String Email){
		setfirstName(firstName);
		setlastName(lastName);
		setStreet(Street);
		setCity(City);
		setState(State);
		setZip(Zip);
		setTelephone(Telephone);
		setEmail(Email);
	}
	public String toString(){
		String a="";
		String Z= Integer.toString(Zip);
		a=firstName+" "+ lastName+" "+Street+" "+ City+" "+ State+" "+Z+" "+ Telephone+" "+ Email;
		return a;
	}
	
	void setfirstName(String Name){
		firstName=Name;
	}
	void setlastName(String Name){
		lastName=Name;
	}
	void setStreet(String Street){
		this.Street=Street;
	}
	void setCity(String City){
		this.City=City;
	}
	void setState(String St){
		this.State=St;
	}
	void setZip(int Z){
		Zip=Z;
	}
	void setTelephone(String Phone){
		Telephone=Phone;
	}
	void setEmail(String Email){
		this.Email=Email;
	}
	
	String getfirstName(){
		return firstName;
	}
	String getlastName(String Name){
		return lastName;
	}
	String getStreet(String Street){
		return Street;
	}
	String getCity(String City){
		return City;
	}
	String getState(){
		return State;
	}
	int getZip(){
		return Zip;
	}
	String getTelephone(){
		return Telephone;
	}
	String getEmail(){
		return Email;
	}
}
