
class AddressBookApplication {
	static void initAddressBookExercise(AddressBook AB) {
		AddressEntry Add1 = new AddressEntry("John","smith","EastCarlos.rd","Hayward","CA",91252,"9251234567","jsmithy@gmail.com");
		AddressEntry Add2 = new AddressEntry("John","smith","bay st","Oakley","CA",9234,"9251234567","johnsmithy@gmail.com");
		AB.add(Add1);
		AB.add(Add2);
	}
	public static void main(String args[]) {

		AddressBook ab = new AddressBook(); //creating an address book
		initAddressBookExercise(ab); //creates a list of address entris
		AddressBook.list();
	}

}

 