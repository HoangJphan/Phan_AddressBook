import java.util.*;
public class AddressBook {
	static ArrayList<AddressEntry> addressEntryList = new ArrayList<AddressEntry>();
	
	public static void list(){
		for(int i=0;i<addressEntryList.size();i++){
			System.out.println(addressEntryList.get(i).toString());
		}
	}
	AddressBook(){
	
	}
	void add(AddressEntry addressEntry)
	{
		addressEntryList.add(addressEntry);
	}
}
