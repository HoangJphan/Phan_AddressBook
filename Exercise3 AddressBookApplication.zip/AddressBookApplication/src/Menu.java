
class Menu {

 

	public static void prompt_FirstName() {

		System.out.println("First Name:");

	}
	public static void prompt_LastName() {

		System.out.println("Last Name:");

	}
	public static void prompt_Street() {

		System.out.println("Street:");

	}
	public static void prompt_City() {

		System.out.println("City:");

	}
	public static void prompt_State() {

		System.out.println("State:");

	}
	public static void prompt_Zip() {

		System.out.println("Zip:");

	}
	public static void prompt_Telephone() {

		System.out.println("Telephone:");

	}
	public static void prompt_Email() {

		System.out.println("Email:");

	}
//*****NOW you create code for the other methods required for this Exercise ********

}